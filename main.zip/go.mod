module ghostops

go 1.27.1
